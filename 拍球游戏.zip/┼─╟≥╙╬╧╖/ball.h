#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Ball
{
private:
	Vector2f m_Position;
	CircleShape m_Shape = CircleShape(10.0f);

	float m_Speed = 1000.0f;
	float m_DirectionX = 0.2f;
	float m_DirectionY = 0.2f;

	int score = 0;  //����
	int lives = 3;  //����

public:
	RenderWindow & window;
	Ball(float startX, float stratY,RenderWindow &w);
	FloatRect getPosition();
	CircleShape getShape();
	float getXVelocity();
	void reboundSides();
	void reboundBatOrTop();
	void reboundBottom();
	void update(Time dt);
	int getScores();
	int getLives();

	void testPosition();
};

#pragma once