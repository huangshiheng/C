#include "ball.h"

Ball::Ball(float startX, float stratY,RenderWindow & w) :window(w)
{
	m_Position.y = stratY;
	m_Position.x = startX;
	m_Shape.setPosition(m_Position);
}

FloatRect Ball::getPosition()
{
	return m_Shape.getGlobalBounds();
}

CircleShape Ball::getShape()
{
	return m_Shape;
}

void Ball::reboundSides()
{
	m_DirectionX = -m_DirectionX;
}

void Ball::reboundBatOrTop()
{
	m_DirectionY = -m_DirectionY;
}
void Ball::reboundBottom()
{
	m_Position.y = 0;
	m_Position.x = 500;
	m_DirectionY = -m_DirectionY;
}

int Ball::getScores()
{
	return score;
}

int Ball::getLives()
{
	return lives;
}

void Ball::update(Time dt)
{
	m_Position.y += m_DirectionY * m_Speed * dt.asSeconds();
	m_Position.x += m_DirectionX * m_Speed * dt.asSeconds();

	m_Shape.setPosition(m_Position);
}

void Ball::testPosition()
{
	if (getPosition().top < 0) {
		reboundBatOrTop();
		score++;
	}
		
	else if (getPosition().top > window.getSize().y) {
		reboundBottom();
		//�����һ��bug ���·�����1
		score--;
		lives--;
		if (lives < 1) {
			score = 0;
			lives = 3;
		}
	}
		
	else if (getPosition().left < 0 || getPosition().left + 10 > window.getSize().x)
		reboundSides();
}
