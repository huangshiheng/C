﻿#include "bat.h"
#include "ball.h"
#include "batBall.h"
#include <sstream>
#include <cstdlib>
#include <SFML/Graphics.hpp>


int main()
{
	//创建一个video模型
	VideoMode vm(1920, 1080);
	//创建和打开一个窗口
	RenderWindow window(vm, "Pong", Style::Fullscreen);
	//球拍 球
	srand((unsigned)time(NULL));
	int x = rand() % 50;
	Ball ball(1920 / 2 +x -25, 0, window);
	Bat  bat(1920 / 2, 1080 - 20, window);
	BatBall batball(window,ball, bat);
	//创建一个文本框
	Text hud;
	//字体
	Font font;
	font.loadFromFile("ds_digital/DS-DIGI.TTF");
	hud.setFont(font);
	hud.setCharacterSize(75);
	hud.setFillColor(Color::White);
	hud.setPosition(20, 20);
	Clock  clock;//时钟

	while (window.isOpen()){
		Event  event;
		while (window.pollEvent(event)){
			if (event.type == Event::Closed) {
				window.close();
			}
		}
		if (Keyboard::isKeyPressed(Keyboard::Escape)) {
			window.close();
		}

		Time dt = clock.restart();

		batball.run(dt);
		std::stringstream ss;
		ss << "Score:" <<  ball.getScores() << "  Lives:" << ball.getLives();
		hud.setString(ss.str());

		window.clear();
		window.draw(hud);
		window.draw(bat.getShape());
		window.draw(ball.getShape());
		window.display();
	}

	return 0;
}
