#include "batBall.h"

BatBall::BatBall(RenderWindow & w, Ball & tball, Bat & tbat) : window(w), bat(tbat), ball(tball)
{
	
}

void BatBall::run(Time dt)
{
	bat.controlPosition();
	ball.testPosition();
	if (ball.getPosition().intersects(bat.getPosition()))
		ball.reboundBatOrTop();
	bat.testPosition();
	bat.update(dt);
	ball.update(dt);
}

