#pragma once
#include <SFML/Graphics.hpp>
#include <cstdlib>
#include "ball.h"
#include "bat.h"

class BatBall
{
private:


public:
	BatBall(RenderWindow & w,Ball & tball, Bat & tbat);
	Ball & ball;
	Bat  & bat;
	RenderWindow & window;
	void run(Time dt);

};
